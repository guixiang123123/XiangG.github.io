# !/bin/bash
# select the country witht the highest mortanlity
# usage: script.sh $input
inputfiles=$2
inputindices=$1
inputyears=$3
grep $inputindices $inputfiles | grep $inputyears | cut -f1,6 | sort -n -k2 | tail -n 1
