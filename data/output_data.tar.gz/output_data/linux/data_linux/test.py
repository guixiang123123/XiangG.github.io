print ('help')
