# !/bin/bash
# select the country witht the highest mortanlity
# usage: script.sh
input=“OECD_Countries_Full.txt"
grep Infant_mortalit $input | grep 2012 | cut -f1,6 | sort -n -k2 | tail -n 1
