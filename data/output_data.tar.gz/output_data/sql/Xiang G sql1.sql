CREATE TABLE "DEMOGRAPHICS" ("County" TEXT, "State" TEXT, "Number_Counties" INTEGER, "Population_Size" INTEGER, "Population_Density" INTEGER, "Poverty" NUMERIC, "White" NUMERIC, "Black" NUMERIC, "Native_American" NUMERIC, "Asian" NUMERIC, "Hispanic" NUMERIC);
CREATE TABLE "MEASURESOFBIRTHANDDEATH" ("County" TEXT, "State" TEXT, "Infant_Mortality" NUMERIC, "Suicide" NUMERIC, "Injury" NUMERIC, "Total_Births" INTEGER, "Total_Deaths" INTEGER);
CREATE TABLE Users (name VARCHAR(128),email VARCHAR(128));
CREATE TABLE __sm_ext_mgmt (`id` integer primary key, `type` text not null , `value` text);
